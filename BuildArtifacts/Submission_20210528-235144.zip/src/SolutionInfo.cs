using System.Reflection;

[assembly: AssemblyProduct("CommerceHub .Net Interview")]
[assembly: AssemblyVersion("0.1.0")]
[assembly: AssemblyFileVersion("0.1.0")]
[assembly: AssemblyInformationalVersion("0.1.0")]
[assembly: AssemblyCopyright("CommerceHub")]